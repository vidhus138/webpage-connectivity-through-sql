<?php 
//connecting to the database 

//define('DB_HOST', 'localhost'); 
//define('DB_NAME', 'practice'); 
//define('DB_USER','root'); 
//define('DB_PASSWORD',''); 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "practice";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error()); //
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error()); 

//inserting Record to the database 

$name = $_POST['name']; 
$email = $_POST['email']; 
$message = $_POST['message']; 
$sql = "INSERT INTO contact(contactName,contactEmail,message)VALUES('$name','$email','$message')"; 

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>

